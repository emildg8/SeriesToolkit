﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$ProjectRoot = '',
    [string]$PublishRepoPath = 'D:/Dev/Script_Rename_ALLVideo/.publish/SeriesToolkit',
    [string]$GitHubRepo = 'emildg8/SeriesToolkit',
    [string]$GistId = '2bf8d27559d9caf2abaa15bfe5c97ac6',
    [string]$SecondaryRemoteName = '',
    [string]$SecondaryRemoteUrl = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = $PSScriptRoot }
$gh = 'C:/Program Files/GitHub CLI/gh.exe'
if (-not (Test-Path -LiteralPath $gh)) { return }

if (-not (Test-Path -LiteralPath $PublishRepoPath)) {
    New-Item -ItemType Directory -Path $PublishRepoPath -Force | Out-Null
    git init "$PublishRepoPath" | Out-Null
}

function Ensure-OriginRemote {
    $remote = (git -C "$PublishRepoPath" remote)
    if ([string]::IsNullOrWhiteSpace($remote)) {
        try { & $gh repo view $GitHubRepo | Out-Null; git -C "$PublishRepoPath" remote add origin "https://github.com/$GitHubRepo.git" } catch { }
    } else {
        try { git -C "$PublishRepoPath" remote set-url origin "https://github.com/$GitHubRepo.git" } catch { }
    }
}

$items = @(Get-ChildItem -LiteralPath $ProjectRoot -Force -ErrorAction SilentlyContinue)
foreach ($it in $items) {
    if ($it.Name -in @('LOGS', 'OLD')) { continue }
    Copy-Item -LiteralPath $it.FullName -Destination $PublishRepoPath -Recurse -Force
}
# Секреты только локально — никогда не публиковать на GitHub
foreach ($secret in @('SeriesToolkit.settings.json', '.env', 'secrets.json', 'tmdb.key', 'kinopoisk.cookie.txt')) {
    $sp = Join-Path $PublishRepoPath $secret
    if (Test-Path -LiteralPath $sp) { Remove-Item -LiteralPath $sp -Force }
}
$parentFetch = Join-Path (Split-Path -Parent $ProjectRoot) 'Fetch-VideoMetadata.ps1'
if (Test-Path -LiteralPath $parentFetch) {
    Copy-Item -LiteralPath $parentFetch -Destination (Join-Path $PublishRepoPath 'Fetch-VideoMetadata.ps1') -Force
}
if (Test-Path -LiteralPath (Join-Path $PublishRepoPath 'LOGS')) {
    Remove-Item -LiteralPath (Join-Path $PublishRepoPath 'LOGS') -Recurse -Force
}
if (Test-Path -LiteralPath (Join-Path $PublishRepoPath 'OLD')) {
    Remove-Item -LiteralPath (Join-Path $PublishRepoPath 'OLD') -Recurse -Force
}

$version = 'unknown'
try {
    $v = Get-Content -LiteralPath (Join-Path $ProjectRoot 'version.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $version = [string]$v.version
} catch { }

git -C "$PublishRepoPath" add . | Out-Null
$changes = (git -C "$PublishRepoPath" status --porcelain)
if (-not [string]::IsNullOrWhiteSpace($changes)) {
    git -C "$PublishRepoPath" commit -m "Auto sync SeriesToolkit v$version" | Out-Null
    Ensure-OriginRemote
    git -C "$PublishRepoPath" push -u origin master | Out-Null
    if (-not [string]::IsNullOrWhiteSpace($SecondaryRemoteUrl) -and -not [string]::IsNullOrWhiteSpace($SecondaryRemoteName)) {
        $remotes = @((git -C "$PublishRepoPath" remote) | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($remotes -notcontains $SecondaryRemoteName) {
            git -C "$PublishRepoPath" remote add $SecondaryRemoteName $SecondaryRemoteUrl
        } else {
            git -C "$PublishRepoPath" remote set-url $SecondaryRemoteName $SecondaryRemoteUrl
        }
        git -C "$PublishRepoPath" push -u $SecondaryRemoteName master | Out-Null
    }
}

# Автоматический релиз текущей версии (tag + release + zip asset)
try {
    if ($version -match '^\d+\.\d+\.\d+$') {
        Ensure-OriginRemote
        $tag = "v$version"
        $head = (git -C "$PublishRepoPath" rev-parse HEAD).Trim()
        $existsTag = (git -C "$PublishRepoPath" tag --list $tag)
        if ([string]::IsNullOrWhiteSpace($existsTag)) {
            git -C "$PublishRepoPath" tag $tag $head
        }
        git -C "$PublishRepoPath" push origin $tag | Out-Null

        $releasesDir = Join-Path $ProjectRoot 'RELEASES'
        if (-not (Test-Path -LiteralPath $releasesDir)) { New-Item -ItemType Directory -Path $releasesDir -Force | Out-Null }
        $zip = Join-Path $releasesDir ("SeriesToolkit-{0}.zip" -f $version)
        if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
        git -C "$PublishRepoPath" archive --format=zip --output="$zip" $tag

        $body = @"
Автоматический релиз SeriesToolkit $version.

Состав:
- исходники toolkit в состоянии тега $tag;
- README/CHANGELOG/version.json текущей версии;
- zip-архив для быстрого тестирования и отката.
"@
        & $gh release view $tag -R $GitHubRepo *> $null
        if ($LASTEXITCODE -eq 0) {
            & $gh release upload $tag $zip -R $GitHubRepo --clobber | Out-Null
        } else {
            & $gh release create $tag $zip -R $GitHubRepo --title "SeriesToolkit $version" --notes $body | Out-Null
        }
    }
} catch { }

# Обновляем gist: если edit не получится, создаём новый.
try {
    $gistArgs = @(
        (Join-Path $ProjectRoot 'README.md'),
        (Join-Path $ProjectRoot 'CHANGELOG.md'),
        (Join-Path $ProjectRoot 'version.json'),
        (Join-Path $ProjectRoot 'SeriesToolkit.ps1'),
        (Join-Path $ProjectRoot 'SeriesToolkit.Engine.ps1'),
        (Join-Path $ProjectRoot 'Start-SeriesToolkitGui.ps1'),
        (Join-Path $ProjectRoot 'Start-SeriesToolkitGui.Engine.ps1'),
        (Join-Path $ProjectRoot 'UiStrings.ps1'),
        (Join-Path $ProjectRoot 'Bump-Version.ps1'),
        (Join-Path $ProjectRoot 'SeriesToolkit.settings.example.json'),
        (Join-Path $ProjectRoot 'SeriesToolkit.settings.README.md')
    )
    foreach ($extra in @('docs/SCREENSHOTS-RU.md')) {
        $ep = Join-Path $ProjectRoot $extra
        if (Test-Path -LiteralPath $ep) { $gistArgs += $ep }
    }
    & $gh gist create @gistArgs `
        --desc "SeriesToolkit v$version — см. репозиторий github.com/emildg8/SeriesToolkit" | Out-Null
} catch { }
